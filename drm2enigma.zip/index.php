<?php
ob_start();


class MyDB extends SQLite3 {
    function __construct() {
        $this->open('channels_new.db');
    }
}

$db = new MyDB();   


if(isset($_GET['playlist-download'])){
    $pp[] = '#EXTM3U';
     
    $channel = $db->query('SELECT * FROM Channels');
    while ($channels = $channel->fetchArray(SQLITE3_ASSOC)) {
        $pp[] = '#EXTINF:-1 group-title="'.$channels['provider'].'", '.$channels['name'];
        $pp[] = 'http://' . $_SERVER['SERVER_ADDR'] . ':8989/' . $channels['id'] . '/ts';
    }

    $file = 'playlist.m3u';
    $f = fopen($file, 'w');
    
    foreach ($pp as $p) {
        fwrite($f, $p . "\n");
    }
    
    header("Content-Description: File Transfer"); 
    header("Content-Type: application/octet-stream"); 
    header("Content-Disposition: attachment; filename=\"". basename($file) ."\""); 
    
    readfile ($file);
    exit(); 
}

if(isset($_GET['bouquet-download'])){
    $e2[] = '#NAME DRM SERVER';
     
    $channel = $db->query('SELECT * FROM Channels');
    while ($channels = $channel->fetchArray(SQLITE3_ASSOC)) {
        $e2[] = '#SERVICE 4097:0:1:0:0:0:0:0:0:0:'.'http%3a//'. $_SERVER['SERVER_ADDR'] .'%3a8989/'. $channels['id'] .'/ts:' . $channels['name'];
        $e2[] = '#DESCRIPTION '.$channels['name'];
    }

    $file = 'userbouquet.drmserver.tv';
    $f = fopen($file, 'w');
    
    foreach ($e2 as $e1) {
        fwrite($f, $e1 . "\n");
    }
    
    header("Content-Description: File Transfer"); 
    header("Content-Type: application/octet-stream"); 
    header("Content-Disposition: attachment; filename=\"". basename($file) ."\""); 
    
    readfile ($file);
    exit(); 
}

if(isset($_POST['add-channel'])){
    $channel = $db->query('SELECT COUNT(*) As count_result FROM Channels WHERE name = "'.$_POST['channelName'].'" AND `provider` = "'.$_POST['channelProvider'].'"');
    $channels = $channel->fetchArray(SQLITE3_ASSOC);
    if($channels['count_result'] == 0){
        $ch_add = $db->query('INSERT INTO Channels (`name`, `url`, `provider`, `lang`) VALUES ("'.$_POST['channelName'].'", "'.$_POST['channelURL'].'", "'.$_POST['channelProvider'].'", "de")');
    
        shell_exec('bin/service.sh stop');
        shell_exec('bin/service.sh start');

        header('location: index.php?true');
    } else {
        header('location: index.php?false');
    }
}

if(isset($_POST['save-channel'])){
    
    $ch_update = $db->query('UPDATE Channels SET `url` = "'.$_POST['channelURL'].'", provider = "'.$_POST['channelProvider'].'", name = "'.$_POST['channelName'].'" WHERE id = "'.$_POST['channelId'].'"');    
    
    shell_exec('bin/service.sh stop');
    shell_exec('bin/service.sh start');

    header('location: index.php');
    
}

if(isset($_POST['save-key'])){

    $delete_provider = $db->query('DELETE FROM `Keys` WHERE channelId= "'.$_POST['channelId'].'"');

    foreach(array_filter($_POST['channelKid']) as $kidKey => $kidValue){
        $key = $db->query('SELECT COUNT(*) As count_result FROM Keys WHERE kid = "'.$kidValue.'" AND channelId = "'.$_POST['channelId'].'"');
        $keys = $key->fetchArray(SQLITE3_ASSOC);
        if($keys['count_result'] == 0){
            $key_add = $db->query('INSERT INTO Keys (`channelId`, `kid`, `key`) VALUES ("'.$_POST['channelId'].'", "'.$kidValue.'", "'.$_POST['channelKey'][$kidKey].'")');
        }
    }

    shell_exec('bin/service.sh stop');
    shell_exec('bin/service.sh start');

    header('location: index.php');
}

if(isset($_POST['save-provider'])){
    
    foreach($_POST['format'] as $formatKey => $formatValue){

        $update_provider = $db->query('UPDATE `Providers` SET `format` = "'.$formatValue.'" WHERE id = "'.$_POST['id'][$formatKey].'"');
    }

    
    shell_exec('bin/service.sh stop');
    shell_exec('bin/service.sh start');

    header('location: index.php');
}

if(isset($_POST['save-provider'])){
    foreach($_POST['format'] as $formatKey => $formatValue){
        $update_provider = $db->query('UPDATE `Providers` SET `format` = "'.$formatValue.'" WHERE id = "'.$id[$formatKey].'"');
    }

    shell_exec('bin/service.sh stop');
    shell_exec('bin/service.sh start');

    header('location: index.php');
}

if(isset($_GET['deleteprovider'])){
    $delete_provider = $db->query('DELETE FROM `Providers` WHERE id = "'.$_GET['id'].'"');
    shell_exec('bin/service.sh stop');
    shell_exec('bin/service.sh start');

    header('location: index.php');
}

if(isset($_GET['deleteChannel'])){
    $delete_channel = $db->query('DELETE FROM `Channels` WHERE id = "'.$_GET['id'].'"');
    $delete_key = $db->query('DELETE FROM `Keys` WHERE channelId = "'.$_GET['id'].'"');

    header('location: index.php');
}

date_default_timezone_set('Europe/Amsterdam');
?>

<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet"/>
        <link href="assets/css/mdb.min.css" rel="stylesheet"/>
        <style>
        .badge {
            padding: 0.35em 0.65em;
            font-size: 0.85em !important;
            line-height: 1.4 !important;
        }

        .input-group>.form-control {
            height: calc(2.133rem + 2px) !important;
           
        }
        </style>
        <title>Widevine DRM Panel</title>
    </head>
    <body>

        <div class="modal fade" id="channelInfo" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Zenderinfo</h5>
                    </div>
                    <div class="modal-body">
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="editChannel" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Bewerk zender</h5>
                    </div>
                    <div class="modal-body">
                        
                    </div>
                </div>
            </div>
        </div>      
        
        <div class="modal fade" id="showKeys" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">DRM Keys</h5>
                    </div>
                    <div class="modal-body">
                        
                    </div>
                </div>
            </div>
        </div>          

        <div class="modal fade" id="addChannel" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Voeg zender toe</h5>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="">
                            
                            <div class="input-group mb-3">
                                <input type="index" class="form-control" name="channelName" id="inputGroup-sizing-default" placeholder="Channel Name">
                                <select class="select" name="channelProvider" id="inputGroupSelect01">
                                    <option selected>Kies provider</option>
                                    <?php
                                    $provider = $db->query('SELECT * FROM `Providers`');
                                    while ($providers = $provider->fetchArray(SQLITE3_ASSOC)) {
                                        echo '<option value="'.$providers['name'].'">'.$providers['name'].'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="input-group mb-3">
                                <input type="index" class="form-control" name="channelURL" placeholder="Url">
                            </div>
                            <button type="submit" name="add-channel" class="btn btn-primary">Voeg zender toe</button>
                        
                        </form>
                    </div>
                </div>
            </div>
        </div>        

        <div class="modal fade" id="showProvider" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Kies provider</h5>
                    </div>
                    <div class="modal-body">

                        <ul class="nav nav-tabs mb-3" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="ex1-tab-1" data-mdb-toggle="tab" href="#ex1-tabs-1" role="tab" aria-controls="ex1-tabs-1" aria-selected="true">Sla provider op</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" id="ex1-tab-2" data-mdb-toggle="tab" href="#ex1-tabs-2" role="tab" aria-controls="ex1-tabs-2" aria-selected="true">Provider toevoegen</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="ex1-content">
                            <div class="tab-pane fade show active" id="ex1-tabs-1" role="tabpanel" aria-labelledby="ex1-tab-1">
                                <form method="post" action="">
                                
                                    <?php
                                    $provider = $db->query('SELECT * FROM `Providers`');
                                    while ($providers = $provider->fetchArray(SQLITE3_ASSOC)) {
                                        
                                        echo '<div class="input-group mb-3">';
                                            echo '<input type="text" class="form-control" id="inputGroup-sizing-default" disabled value="'.$providers['name'].'" />';
                                            echo '<select name="format[]" class="select" style="width: 100px">';
                                                echo '<option value="MPEG-TS" '.($providers['format'] == 'MPEG-TS' ? 'selected' : '').'>MPEG-TS</option>';
                                                echo '<option value="HLS" '.($providers['format'] == 'HLS' ? 'selected' : '').'>HLS</option>';
                                            echo '</select>';
                                            echo '<input type="hidden" name="id[]" value="'.$providers['id'].'" />';
                                        echo '</div>';                                    
                                    }
                                    ?>
                                    
                                    <button type="submit" name="save-provider" class="btn btn-success" value="Save Provider">Sla provider op</button>
                                </form>
                            </div>

                            <div class="tab-pane fade show" id="ex1-tabs-2" role="tabpanel" aria-labelledby="ex1-tab-2">
                                <form method="post" action="">
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" name="name" placeholder="name" />
                                        <select name="format" class="select" style="width: 100px">
                                            <option value="MPEG-TS">MPEG-TS</option>
                                            <option value="HLS">HLS</option>
                                        </select>
                                    </div>                                    
                                    
                                    <button type="submit" name="add-provider" class="btn btn-success" value="Add Provider">Provider toevoegen</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>             

        <div class="px-4 py-5  text-center">
            <img src="assets/image/logo.png" alt="widevine" width="320" height="162">
            <h1 class="display-1 fw-bold">DRM2ENIGMA DRM PANEL</h1>
            <div class="col-lg-4 mx-auto">
                <p class="lead">Een paneel om de DRM streams op een Enigma2 reciever te kunnen gebruiken.</p>
				<p>Dit paneel is in beta fase, vermeld problemen via de github pagina. Er zijn wat bugs, je kunt op dit moment niet zelf een provider toevoegen:(</p>
                <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
					<a href="index.php?bouquet-download" type="button" class="btn btn-primary btn-sm px-4 gap-3">Download bouquet</a>
                    <a href="index.php?playlist-download" type="button" class="btn btn-primary btn-sm px-4 gap-3">Download afspeellijst</a>
                    <a href="#" onclick="addChannel()" type="button" class="btn btn-warning btn-sm px-4 gap-3">Zender toevoegen</a>
                    <a href="#" onclick="showProvider()" type="button" class="btn btn-warning btn-sm px-4 gap-3">Providers</a>
                </div>
            </div>
        </div>

        <div class="container">
           

            <div class="mt-5 mb-5">
            
                <table class="table text-nowrap" id="channels">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Zender</th>
                            <th>Status</th>
                            <th>Video Index</th>
                            <th>Provider</th>
                            <th>Key</th>
                            <th class="text-end">Actie</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // INDEX SAVE
                        if(isset($_POST['saveIndex'])){
                            $videoUpdate = $db->query('UPDATE Channels SET vIndex = "'.$_POST['videoIndex'].'" WHERE id = "'.$_POST['chId'].'"');
                        }

                        $aux = shell_exec('ps aux | grep \'ffmpeg\'');
                        preg_match_all('/service_name=(.*?) -metadata/', $aux, $output_array);

                        $channel = $db->query('SELECT Channels.id, Channels.name, Channels.provider, Channels.url, Keys.kid, Keys.key FROM Channels LEFT JOIN Keys ON Channels.id = Keys.channelId GROUP BY Channels.id');
                        while ($channels = $channel->fetchArray(SQLITE3_ASSOC)) {

                            if(in_array($channels['name'], $output_array[1])){
                                $status = '<span class="badge badge-success">Actief</span>';
                            } else {
                                $status = '<span class="badge badge-warning">On-demand</span>';
                            }

                            echo '<tr>';
                                echo '<td>'.$channels['id'].'</td>';
                                echo '<td>'.$channels['name'].'</td>';
                                echo '<td>'.$status.'</td>';
                                echo '<td><a href="#" onclick="openInfo('.$channels['id'].')" data-id="'.$channels['id'].'">Info</a></td>';
                                echo '<td>'.$channels['provider'].'</td>';
                                echo '<td>'.($channels['kid'] != '' ? '<span class="badge badge-success" role="button" onclick="showKeys('.$channels['id'].')">Key aanwezig</span>' : '<span class="badge badge-danger" onclick="showKeys('.$channels['id'].')">Key niet aanwezig</span>').'</td>';
                                echo '
                                    <td class="text-end">
                                        <a href="http://' . $_SERVER['SERVER_ADDR'] . ':8989/'.$channels['id'].'/ts" title="M3u link">Kopieer M3U Link</a>
                                        &nbsp;
                                        |
                                        &nbsp;
                                        <a href="#" onclick="editChannel('.$channels['id'].')" title="Edit">Zender wijzigen</a>
                                        &nbsp;
                                        |
                                        &nbsp;
                                        <a href="#" onclick="deleteChannel('.$channels['id'].')" title="Edit">Zender verwijderen</a>
                                    </td>
                                ';
                            echo '</tr>';
                        }

                        ?>
                    </tbody>
                </table>
            </div>
            
        </div>

        <!-- Optional JavaScript; choose one of the two! -->

        <!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script type="text/javascript" src="assets/js/mdb.min.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <script>
        $(document).ready(function () {
            table = $('#channels').DataTable({ stateSave: true, pageLength: 10, order: false });
        
            // CLOSE MODAL
            $('button[data-dismiss="channelInfo"]').click(function(){
                var channelModal = new bootstrap.Modal(document.getElementById('channelInfo'));
                channelModal.hide();
            });

            $('.modal').on('hidden', function() {
                clear();
            });

        });

        function addProvider(){
            var data_id = parseInt($("provider-block:last").attr("data-id"));
            var newDataID = data_id + 1;
            $(".provider-block:first").clone().attr("data-id", newDataID).appendTo(".providers");
        }

        function deleteProvider(id){
            alert(id);
            $('[data-id='+id+']').remove();
  
        }

        // SHOW CH INFO
        function openInfo(id){
            var channelId = id;
            var channelModal = new bootstrap.Modal(document.getElementById('channelInfo'));
            var data = 'showChannelInfo&id='+channelId;
            $.post('xhr/ajax.php', data, function(response){
                $('.modal-body').html(response)
            });
            channelModal.show();
        }

        function editChannel(id){
            var channelId = id;
            var editChannelModal = new bootstrap.Modal(document.getElementById('editChannel'));
            var data = 'editChannel&id='+channelId;
            $.post('xhr/ajax.php', data, function(response){
                $('.modal-body').html(response)
            });
            editChannelModal.show();
        }       
        
        function showKeys(id){
            var channelId = id;
            var showKeysModal = new bootstrap.Modal(document.getElementById('showKeys'));
            var data = 'showKeys&id='+channelId;
            $.post('xhr/ajax.php', data, function(response){
                $('.modal-body').html(response)
            });
            showKeysModal.show();
        }   
        
        function deleteChannel(id){
            Swal.fire({
                title: 'Weet je het zeker?',
                text: 'Je kunt dit niet ongedaan maken!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ja',
            }).then((result) => {
               
                if (result.isConfirmed) {
                    window.location.href = '?deleteChannel&id='+id;
                } else if (result.isDenied) {
                    Swal.fire('Wijzigingen niet opgeslagen', '', 'info')
                }
            })
        }

        function addChannel(){
            var addChannelModal = new bootstrap.Modal(document.getElementById('addChannel'));
            addChannelModal.show();
        }

        function showProvider(){
            var showProviderModal = new bootstrap.Modal(document.getElementById('showProvider'));
            showProviderModal.show();
        }

        function copyM3U(){
            var mytext = document.getElementById("m3u");
            mytext.select(); //select text field
            mytext.setSelectionRange(0, 99999); // For mobile devices
            document.execCommand("copy");
            alert("Kopieer tekst naar clipboard: " + mytext.value);
        }

        </script>

        
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  
    </body>
</html>
<?php ob_end_flush(); ?>