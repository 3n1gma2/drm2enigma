if [ $(pgrep -cf $0) -le 2 ]
then
	echo "not running"

	while [ 1 -eq 1 ]; do

		php /opt/share2box-drm/crons/dazn-event.php		
		sleep 1
	
	done

else
	echo "running, do nothing"
fi