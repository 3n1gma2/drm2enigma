!#/bin/bash
echo "Restarting Share2box-DRM"
rm -rf /tmp/ramdisk/*
pkill java
sh /opt/share2box-drm/shell/service.sh start
rm /opt/share2box-drm/nohup.out
echo "Done"
