<?php
date_default_timezone_set('Europe/Berlin');
$password = 'Onkel1965';
$server_ip = '176.9.57.122';
$port = '22';


date_default_timezone_set('Europe/Berlin');
$available_event_ch = array('DAZN_EVENT_01','DAZN_EVENT_02','DAZN_EVENT_03','DAZN_EVENT_04','DAZN_EVENT_05','DAZN_EVENT_06','DAZN_EVENT_07','DAZN_EVENT_08','DAZN_EVENT_09','DAZN_EVENT_10','DAZN_EVENT_11','DAZN_EVENT_12','DAZN_EVENT_13','DAZN_EVENT_14','DAZN_EVENT_15');

$add_dazn_ch['DAZN_EVENT_01'] = array('ch_id' => 985, 'ch_name' => 'DAZN_EVENT_01');
$add_dazn_ch['DAZN_EVENT_02'] = array('ch_id' => 986, 'ch_name' => 'DAZN_EVENT_02');
$add_dazn_ch['DAZN_EVENT_03'] = array('ch_id' => 987, 'ch_name' => 'DAZN_EVENT_03');
$add_dazn_ch['DAZN_EVENT_04'] = array('ch_id' => 988, 'ch_name' => 'DAZN_EVENT_04');
$add_dazn_ch['DAZN_EVENT_05'] = array('ch_id' => 989, 'ch_name' => 'DAZN_EVENT_05');
$add_dazn_ch['DAZN_EVENT_06'] = array('ch_id' => 990, 'ch_name' => 'DAZN_EVENT_06');
$add_dazn_ch['DAZN_EVENT_07'] = array('ch_id' => 991, 'ch_name' => 'DAZN_EVENT_07');
$add_dazn_ch['DAZN_EVENT_08'] = array('ch_id' => 992, 'ch_name' => 'DAZN_EVENT_08');
$add_dazn_ch['DAZN_EVENT_09'] = array('ch_id' => 993, 'ch_name' => 'DAZN_EVENT_09');
$add_dazn_ch['DAZN_EVENT_10'] = array('ch_id' => 994, 'ch_name' => 'DAZN_EVENT_10');
$add_dazn_ch['DAZN_EVENT_11'] = array('ch_id' => 995, 'ch_name' => 'DAZN_EVENT_11');
$add_dazn_ch['DAZN_EVENT_12'] = array('ch_id' => 996, 'ch_name' => 'DAZN_EVENT_12');
$add_dazn_ch['DAZN_EVENT_13'] = array('ch_id' => 997, 'ch_name' => 'DAZN_EVENT_13');
$add_dazn_ch['DAZN_EVENT_14'] = array('ch_id' => 998, 'ch_name' => 'DAZN_EVENT_14');
$add_dazn_ch['DAZN_EVENT_15'] = array('ch_id' => 999, 'ch_name' => 'DAZN_EVENT_15');

$cache_file = '/opt/share2box-drm/upcomming_events.json';

// GET HOMESCREEN IDs
$event_ids = file_get_contents('https://rails.discovery.indazn.com/eu/v8/rails?groupId=home&country=de&openBrowse=false');
$event_ids = json_decode($event_ids, true);

// GET ALL EVENTS
$all_events = array();
foreach($event_ids['Rails'] as $event_key => $event_value){
    $live_events = json_decode(file_get_contents('https://rail-router.discovery.indazn.com/eu/v3/Rail?platform=web&id='.$event_value['Id'].'&country=de&languageCode=de&params=PageType:Home%3BContentType:None'), true);
    array_push($all_events, $live_events);
}

// SET UPCOMMING EVENTS ARRAY
$upcomming_events = array();
foreach($all_events as $event){
    foreach($event['Tiles'] as $tile){
        if($tile['VideoType'] == 'Live'){
            $upcomming_events[$tile['Title']] = array('asset_id' => $tile['AssetId'], 'event_label' => $tile['Title'], 'event_start' => $tile['Start'], 'event_end' => $tile['End']);
        }
    }
}

file_put_contents($cache_file, json_encode($upcomming_events), LOCK_EX);

$upcomming_events = file_get_contents($cache_file);
$upcomming_events_array = json_decode($upcomming_events, true);

// DEL DEFAULT CHANNELS
unset($upcomming_events_array['DAZN 1']);
unset($upcomming_events_array['DAZN 2']);
unset($upcomming_events_array['Eurosport 1']);
unset($upcomming_events_array['Eurosport 2']);
unset($upcomming_events_array['Red Bull TV']);
unset($upcomming_events_array['SPORTDIGITAL FUSSBALL']);
unset($upcomming_events_array['NBA TV']);
unset($upcomming_events_array['NFL Network']);
unset($upcomming_events_array['MLB Network']);
unset($upcomming_events_array['Unbeaten']);

// GET ONLY LIVE EVENTS TO UPCOMMING EVENTS
$current_events = array();
foreach($upcomming_events_array as $checking){
    $start_time = strtotime($checking['event_start']);
    $end_time = strtotime($checking['event_end']);
    
    $response = file_get_contents('https://vikitv.app/dazn_event.php?dazn_events&asset_id='.$checking['asset_id']);
    $response = json_decode($response, true);
    $response = json_decode($response, true);

    if($response['Asset']['IsLive'] == 1){
        $current_events[] = $checking['event_label'];
    } else {
        unset($upcomming_events_array[$checking['event_label']]);
    }
   
}

// UNSET USED CHANNEL
foreach($available_event_ch as $available_key => $available_ch){
    if(file_exists('/opt/share2box-drm/events/'.$available_ch.'.txt')){
        $event_name = file_get_contents('/opt/share2box-drm/events/'.$available_ch.'.txt');
        unset($available_event_ch[$available_key]);
        unset($upcomming_events_array[$event_name]);
    }
}


// IF UPCOMMING LIVE EVENT EXISTS START IT
if(count($upcomming_events_array) > 0){
    $cur_event = current($upcomming_events_array);
                    
    $response = file_get_contents('https://vikitv.app/dazn_event.php?dazn_events&asset_id='.$cur_event['asset_id']);
    $response = json_decode($response, true);
    $response = json_decode($response, true);

    if(!file_exists('/opt/share2box-drm/events/'.current($available_event_ch).'.txt')){


        class MyDB extends SQLite3 {
            function __construct() {
                $this->open('/opt/share2box-drm/channels_new.db');
            }
        }
        
        
        $db = new MyDB();   


        // GET CURRENT EVENT                
        $delete_key = $db->query('DELETE FROM `Keys` WHERE channelId = "'.$add_dazn_ch[current($available_event_ch)]['ch_id'].'"');
        $delete_channel = $db->query('DELETE FROM `Channels` WHERE id = "'.$add_dazn_ch[current($available_event_ch)]['ch_id'].'"');

        shell_exec('curl -g -X POST -H "Content-Type: application/json" -d \'{"query":"query{stop(id: '.$add_dazn_ch[current($available_event_ch)]['ch_id'].')}"}\' http://'.$_SERVER['SERVER_ADDR'].':8989/api/graphql');
        shell_exec('sshpass -p '.$password.' ssh -f -oUserKnownHostsFile=/dev/null -oStrictHostKeyChecking=no root@'.$server_ip.' -p '.$port.' kill -9 `pgrep -f '.current($available_event_ch).'`');

        // GO TO SLEEP FOR 3 SECONDS
        sleep(3);

        $url_parse = parse_url($response['PlaybackDetails'][0]['ManifestUrl']);
        $url_parse['host'] = 'dcalivedazn.akamaized.net';
        $new_url = $url_parse['scheme'].'://'.$url_parse['host'].$url_parse['path'].'?'.$url_parse['query'];

        $dazn_event_ch_add = $db->query('INSERT INTO Channels (`id`, `name`, `url`, `provider`, `lang`) VALUES ("'.$add_dazn_ch[current($available_event_ch)]['ch_id'].'", "'.$add_dazn_ch[current($available_event_ch)]['ch_name'].'", "'.$new_url.'", "dazn-de", "de")');
        $dazn_key_add = $db->query('INSERT INTO Keys (`channelId`, `kid`, `key`) VALUES ("'.$add_dazn_ch[current($available_event_ch)]['ch_id'].'", "cfb5e2b73bef4f3c878f25ab86a7451f", "0d6712bf2a84edcc93d001a9613f6fec")');
        shell_exec('curl -g -X POST -H "Content-Type: application/json" -d \'{"query":"query{play(id: '.$add_dazn_ch[current($available_event_ch)]['ch_id'].')}"}\' http://'.$_SERVER['SERVER_ADDR'].':8989/api/graphql');
        

        file_put_contents('/opt/share2box-drm/events/'.current($available_event_ch).'.txt', $cur_event['event_label']); 
        
    }
}
    
// EVENT STOP
$files = array_diff(scandir('/opt/share2box-drm/events/'), array('.', '..'));
foreach($files as $file){
    
    $label = file_get_contents('/opt/share2box-drm/events/'.$file);
    if(!in_array($label, $current_events)){
        
        class MyDB extends SQLite3 {
            function __construct() {
                $this->open('/opt/share2box-drm/channels_new.db');
            }
        }
        
        $db = new MyDB();   

        shell_exec('rm /opt/share2box-drm/events/'.$file);
        shell_exec('curl -g -X POST -H "Content-Type: application/json" -d \'{"query":"query{stop(id: '.$add_dazn_ch[current($available_event_ch)]['ch_id'].')}"}\' http://'.$_SERVER['SERVER_ADDR'].':8989/api/graphql');
        shell_exec('sshpass -p '.$password.' ssh -f -oUserKnownHostsFile=/dev/null -oStrictHostKeyChecking=no root@'.$server_ip.' -p '.$port.' kill -9 `pgrep -f '.substr($file, 0, -4).'`');

        // GET CURRENT EVENT                
        $delete_key = $db->query('DELETE FROM `Keys` WHERE channelId = "'.$add_dazn_ch[substr($file, 0, -4)]['ch_id'].'"');
        $delete_channel = $db->query('DELETE FROM `Channels` WHERE id = "'.$add_dazn_ch[substr($file, 0, -4)]['ch_id'].'"');
        
    }
}
?>